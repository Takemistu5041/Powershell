﻿#本番環境用設定ファイル

[Logging]
TRACELEVEL=0x00000003
TRACEPATH=%PROGRAMDATA%\OQS-Auth
TRACESIZE=500000

[CERT]
ISSUERNAME=Online Billing NW System

[WEBAPI]
#ログイン
LOGINURL=https://hweb.oqs.onshikaku.org/oqs-api-pro/MSA12040/ILI12040SV01/auth

# 顔認証用
NOPINURL=wss://hweb-mnc.oqs.onshikaku.org/nopininsuranceface

PINURL=wss://hweb-mnc.oqs.onshikaku.org/pininsuranceface

NOPINLINKURL=wss://hweb-mnc.oqs.onshikaku.org/nopinlinkface

#アカウント管理（環境設定)
ACCOUNTMANHOST=https://hweb-mnc.oqs.onshikaku.org/api/staffFaceAuth/users/useTerminal

#アカウント管理（リフレッシュ)
ACCOUNTAUTHHOST=https://hweb.oqs.onshikaku.org/oqs-api-pro/MSA12041/ILI12041SV01/refresh

#証跡出力
DISCARDLOGURL=https://hweb-mnc.oqs.onshikaku.org/faceapistage/report

#精度設定ファイル
ACCURACYFILEURL=https://hweb-mnc.oqs.onshikaku.org/faceapistage/accuracyfile/get

#閲覧同意フラグ通知
NOTIFYAGREEMENTFLAGURL=https://hweb-mnc.oqs.onshikaku.org/oqs-api-pro/MSA01080/QUC01080SV01/regist

#閲覧同意制御フラグ取得
DISPCONTROLINFOURL=https://hweb-mnc.oqs.onshikaku.org/oqs-api-pro/MSA01100/QUC01100SV01/search

